package gestionpedidos.pedido;

public class Cliente {
	private String codigo;
		
	public Cliente(String codigo) {
		this.codigo = codigo;		
	}
	
	public String getCodigo(){
		return codigo;
	}
}
