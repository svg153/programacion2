package gestionpedidos.pedido;

public class Restaurante {
	private String codigo;	
		
	public Restaurante(String codigo) {
		this.codigo = codigo;		
	}

	public String getCodigo(){
		return codigo;
	}
}
